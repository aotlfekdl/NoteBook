package com.kh.diamelo.controller;

import com.kh.diamelo.domain.vo.PageInfo;
import com.kh.diamelo.domain.vo.User_Info;
import com.kh.diamelo.service.EmployeeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;

@Controller
public class EmployeeController {
    private EmployeeService employeeService;

    // 인사관리 페이지로 가기
    @GetMapping("employee.erp")
    public String employee() {
        return "erpPage/employeePage";
    }

    // 인사 관리자 페이지로 가기
    @GetMapping("empAdmin.erp")
    public String empAdmin() {return "erpPage/employeeAdminPage";}

    // 인사 상세 페이지로 가기
    @GetMapping("empDetail.erp")
    public String empDetail() {return "erpPage/employeeDetailPage";}

    //인사 상세 페이지에서 수정하기 눌렀을 때의 redirect
    @PostMapping("empAdmin.erp")
    public String empAdminPost() {return null;}

    @GetMapping("empList.erp")
    public String selectUserInfoList(@RequestParam(defaultValue = "1") int cpage, Model model) {
        int UserCount = employeeService.selectUserInfoCount();

        PageInfo pi = new PageInfo(UserCount, cpage, 10, 10);
        ArrayList<User_Info> list =employeeService.selectUserInfoList(pi);

        model.addAttribute("list", list);
        model.addAttribute("pi", pi);

        return "erpPage/employeePage";}




}
