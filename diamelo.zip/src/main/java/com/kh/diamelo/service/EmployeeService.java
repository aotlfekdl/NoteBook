package com.kh.diamelo.service;

import com.kh.diamelo.domain.vo.PageInfo;
import com.kh.diamelo.domain.vo.User_Info;

import java.util.ArrayList;

public interface EmployeeService {

    int selectUserInfoCount();

    ArrayList<User_Info> selectUserInfoList(PageInfo pi);
}
