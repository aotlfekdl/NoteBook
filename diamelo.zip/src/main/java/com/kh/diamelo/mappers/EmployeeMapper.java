package com.kh.diamelo.mappers;

import com.kh.diamelo.domain.vo.User_Info;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.RowBounds;

import java.util.ArrayList;

@Mapper
public interface EmployeeMapper {

    int selectUserInfoCount();

    ArrayList<User_Info> selectUserInfoList(RowBounds rowBounds);
}
