package com.kh.diamelo.mappers;

public interface TestMapper {
}
